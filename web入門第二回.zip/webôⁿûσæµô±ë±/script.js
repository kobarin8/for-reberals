var open =document.querySelector("#open");
var counter =document.querySelector("#counter");
var top =document.querySelector("#top");
var center =document.querySelector("#center");
var down =document.querySelector("#down");
var menu =document.querySelector("#hamburger_menu");

var cen1 =document.querySelector("#cen1");
var cen2 =document.querySelector("#cen2");
var cen3 =document.querySelector("#cen3");
var cen4 =document.querySelector("#cen4");

//オープニング
function start(){
    open.style ="transform:translateY(-100%); opacity:0.6;"
}
//ヘッダーの挙動
function menu_open(){
    menu.style ="transform:translateX(5%) skewX(-3deg);"
}
function menu_close(){
    menu.style ="transform:translateX(200%) skewX(0deg);"
}
//css変更プログラム
function change_css(z){
    var CSS_kun = document.querySelector("#css_kun")
    var CSS_name = document.querySelector("#cssName");
    CSS_kun.style =z;
    CSS_name.textContent =z;
}

//スクロールした時の挙動
window.onscroll = function(){
    
    //ページの高さを取得
    var s =window.pageYOffset;
    //ページの高さの数値の小数点切り捨て
    var scrollpoint = Math.floor(s);
    //左下の数字をスクロールする度に書き換える
    counter.textContent=scrollpoint;
    
    var one_scroll = window.innerHeight;
    
    var word1 = document.querySelector("#centerword1");
    var word2 = document.querySelector("#centerword2");
    var word3 = document.querySelector("#centerword3");
    var word4 = document.querySelector("#centerword4");
    
    if
    (s>one_scroll)
    {cen1.style="opacity:1;";
     word1.style="transform:translateY(0%);";
    }
    if
    (s>one_scroll*2)
    {cen2.style="opacity:1;";
     word2.style="transform:translateY(0%);opacity:1";
    }
    if
    (s>one_scroll*3)
    {cen3.style="opacity:1;";
     word3.style="transform:translateY(0%);opacity:1;";
    }
    if
    (s>one_scroll*4)
    {cen4.style="opacity:1;";
     word4.style="opacity:1; transform:translate(50%,50%) rotate(-360deg);";
    }

}
